class Game {
  constructor() {
    
  }

  start() {
// if (gameState === 0){
 
      form = new Form();
      form.display();
      player = new Player();
      player.getCount();
 //}

  }

}
